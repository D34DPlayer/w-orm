import { JSONOutput } from 'typedoc';
import { YafHTMLElement } from '../../../index.js';
export declare class YafSignatureInferred extends YafHTMLElement<JSONOutput.InferredType> {
    onConnect(): void;
}
