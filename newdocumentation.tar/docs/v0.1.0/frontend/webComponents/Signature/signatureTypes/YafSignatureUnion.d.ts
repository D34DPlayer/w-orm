import { JSONOutput } from 'typedoc';
import { YafHTMLElement } from '../../../index.js';
export declare class YafSignatureUnion extends YafHTMLElement<JSONOutput.UnionType> {
    onConnect(): void;
}
