import { JSONOutput } from 'typedoc';
import { YafHTMLElement } from '../../../index.js';
export declare class YafSignatureIntersection extends YafHTMLElement<JSONOutput.IntersectionType> {
    onConnect(): void;
}
