"use strict"
export const DOC_VERSIONS = [
	'dev',
	'v0.1',
];
